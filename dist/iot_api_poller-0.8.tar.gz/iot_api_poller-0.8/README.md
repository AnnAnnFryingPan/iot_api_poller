# database_connection package
Wraps connection to database. E.g. InfluxDb
